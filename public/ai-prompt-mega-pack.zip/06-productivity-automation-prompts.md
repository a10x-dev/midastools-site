# Midas Tools — AI Prompt Mega Pack
# 06: Productivity & Automation Prompts

Work smarter, not harder. These prompts help you make better decisions, automate workflows, research faster, and optimize your time.

---

## Variables Reference

```
[TASK] — The specific task or project
[GOAL] — What you're trying to achieve
[CONTEXT] — Relevant background information
[TIMEFRAME] — Available time or deadline
[TOOLS] — Software/tools you currently use
[YOUR ROLE] — Your position or function
[CONSTRAINTS] — Limitations (budget, time, resources)
[DATA] — Any data or information to analyze
```

---

## Prompt 1: Decision-Making Framework

### Prompt

```
Help me make a decision about [DECISION TO MAKE].

Context:
- Situation: [DESCRIBE THE SITUATION]
- Options I'm considering:
  A) [OPTION A]
  B) [OPTION B]
  C) [OPTION C — if applicable]
- Decision deadline: [TIMEFRAME]
- What matters most: [TOP 2-3 PRIORITIES]
- Constraints: [CONSTRAINTS]
- Risk tolerance: [LOW / MEDIUM / HIGH]

Analyze using:

**1. Pros/Cons Matrix:**
For each option — list 5 pros and 5 cons with weighted importance (1-5)

**2. Second-Order Thinking:**
For each option — what happens in 1 month, 6 months, 1 year?

**3. Regret Minimization:**
Which option will I least regret at age 80?

**4. 10/10/10 Rule:**
How will I feel about this in 10 minutes, 10 months, 10 years?

**5. Reversibility Assessment:**
Is this a one-way door or two-way door? Can I undo it?

**Recommendation:**
- Which option to choose
- Confidence level: High / Medium / Low
- Key assumption that could change the answer
- What information would make this clearer

Be direct. Tell me what you'd do and why.
```

### How to Use
Use this for any decision that will take more than 1 hour to impact. Small decisions: just pick one and go.

---

## Prompt 2: Weekly Planning System

### Prompt

```
Help me plan my week for maximum productivity.

My context:
- Role: [YOUR ROLE]
- Top 3 goals this quarter: [LIST THEM]
- This week's obligations: [MEETINGS, DEADLINES, COMMITMENTS]
- Energy pattern: [WHEN AM I MOST FOCUSED — morning, afternoon, evening]
- Available work hours: [HOURS PER DAY]
- Tools I use: [CALENDAR, TODO APP, ETC.]

Create:

**1. Weekly priorities (max 3):**
- The 3 things that, if completed, make this a great week
- Why each matters for my quarterly goals
- Estimated hours for each

**2. Daily schedule template:**
For each day (Mon-Fri):
- Focus block (2-3 hours of deep work — when?)
- Meetings & calls (clustered together)
- Admin/email (batched)
- Exercise/breaks
- Learning/reading

**3. Task categorization:**
Sort my obligations into:
- 🔴 Must do (deadline this week, high impact)
- 🟡 Should do (important but can flex)
- 🟢 Could do (nice to have)
- ❌ Eliminate (busy work, delegate, or delete)

**4. Time blocking suggestion:**
- Block schedule for the week
- Buffer time built in (15 min between meetings)
- One "no meeting" day

**5. Friday review prompts:**
- What did I accomplish?
- What didn't get done and why?
- What's the #1 priority for next week?
- What do I need to say no to?
```

### How to Use
Do this Sunday evening or Monday morning. Spend 30 minutes planning to save 5 hours of reactive work.

---

## Prompt 3: Research & Analysis Assistant

### Prompt

```
Help me research [TOPIC] thoroughly and present findings clearly.

Research objective: [WHAT I NEED TO KNOW AND WHY]
Decision this supports: [WHAT I'LL DO WITH THIS INFORMATION]
Depth needed: [QUICK OVERVIEW / MODERATE / COMPREHENSIVE]
Time available: [HOW LONG I HAVE]

Research structure:

**1. Executive summary (5 bullet points)**
- The top-line findings a busy person needs to know

**2. Background & context**
- What's happening in this space
- Key trends and data points
- Timeline of important events

**3. Key findings (organized by theme)**
For each finding:
- The insight
- Supporting evidence
- Source type (study, expert opinion, market data, anecdote)
- Confidence level: 🟢 High / 🟡 Moderate / 🔴 Low

**4. Competitive/comparative analysis**
- Key players or alternatives
- Comparison table (features, pricing, pros/cons)
- Market positioning

**5. Risks & considerations**
- What could go wrong
- What I might be missing
- Counterarguments to the main findings

**6. Recommendations**
- What to do based on this research
- Next steps
- What additional research would help

**7. Sources & further reading**
- Categorized list of sources to check
- Key people/experts to follow

Present data in tables where possible. Be opinionated, not just descriptive.
```

### How to Use
Start every major decision with 30-60 minutes of structured research. Bad research leads to bad decisions.

---

## Prompt 4: Automation Workflow Builder

### Prompt

```
Help me automate [TASK] that I currently do manually.

Current process:
- Task: [DESCRIBE WHAT YOU DO MANUALLY]
- Frequency: [HOW OFTEN]
- Time it takes: [MINUTES/HOURS PER OCCURRENCE]
- Tools involved: [SOFTWARE/APPS CURRENTLY USED]
- Input: [WHAT TRIGGERS THIS TASK]
- Output: [WHAT THE END RESULT SHOULD BE]
- Errors that happen: [COMMON MISTAKES IN MANUAL PROCESS]

Design an automation:

**1. Workflow diagram:**
- Trigger → Step 1 → Step 2 → ... → Output
- Decision points (if X then Y)
- Error handling (what happens if something fails)

**2. Tool recommendation:**
- Best tool for this: [ZAPIER / MAKE / N8N / CUSTOM SCRIPT]
- Why this tool vs. alternatives
- Estimated cost
- Setup difficulty: Easy / Medium / Hard

**3. Step-by-step setup guide:**
For each step in the workflow:
- What it does
- How to configure it
- Settings and parameters
- Test criteria

**4. ROI calculation:**
- Current time spent: [X hours/week]
- Time after automation: [X hours/week]
- Hours saved per month
- Dollar value of saved time (at your hourly rate)
- Tool cost vs. time savings

**5. Maintenance plan:**
- What to monitor
- How often to check
- Common failure points
- How to troubleshoot

**6. Enhancement ideas:**
- V2 improvements to add later
- Related processes to automate next
```

### How to Use
Automate your most repetitive task first. Start simple — don't over-engineer. You can always improve later.

---

## Prompt 5: Learning Accelerator

### Prompt

```
Create a learning plan to help me master [SKILL/TOPIC] efficiently.

Context:
- What I want to learn: [SKILL/TOPIC]
- Why: [GOAL — new job, business need, personal interest]
- Current level: [BEGINNER / INTERMEDIATE / ADVANCED]
- Available time: [HOURS PER WEEK]
- Learning style: [READING / VIDEO / HANDS-ON / DISCUSSION]
- Budget for resources: [AMOUNT]
- Deadline: [TIMEFRAME]

Create:

**1. Learning roadmap:**
- Phase 1 (Foundation): What to learn first + resources
- Phase 2 (Application): Hands-on projects
- Phase 3 (Mastery): Advanced topics + real-world application
- Estimated time for each phase

**2. Resource list:**
- Top 3 free resources (with links/descriptions)
- Top 3 paid resources (with costs and ROI justification)
- Communities to join
- Experts to follow
- Newsletters/podcasts on this topic

**3. Practice plan:**
- Weekly practice schedule
- Project ideas for each phase
- How to get feedback
- Milestones to track progress

**4. The 80/20 analysis:**
- Which 20% of this topic will give me 80% of practical value?
- What can I skip or learn later?
- Minimum viable knowledge to be productive

**5. Accountability system:**
- How to track progress
- Study group or partner suggestions
- Reward milestones

**6. Common pitfalls:**
- Mistakes beginners make
- What to avoid
- When to know you're ready for the next level
```

### How to Use
Focus on the 80/20 first. Learn by doing, not just consuming. Build something with new knowledge within the first week.

---

## Prompt 6: Email Inbox Zero System

### Prompt

```
Help me design an email management system to reach and maintain inbox zero.

My email situation:
- Emails per day: [NUMBER]
- Email client: [GMAIL / OUTLOOK / OTHER]
- Types of emails: [WORK, NEWSLETTERS, CLIENTS, NOTIFICATIONS, etc.]
- Current inbox count: [NUMBER]
- Time currently spent on email: [HOURS/DAY]
- Biggest email pain point: [WHAT FRUSTRATES YOU]

Design:

**1. Email triage system:**
- Decision tree: For every email, ask these 3 questions
- Action categories: Do / Delegate / Defer / Delete / Archive
- The 2-minute rule: If it takes <2 min, do it now

**2. Folder/Label structure:**
- Recommended folders (keep it under 10)
- Color coding system
- What goes where

**3. Filter/Rule automation:**
- Auto-sort newsletters to a "Read Later" folder
- Priority sender rules
- Notification emails → auto-archive
- Meeting confirmations → auto-label

**4. Email batching schedule:**
- When to check email (3 specific times)
- How long each batch should take
- What to do outside batch times

**5. Response templates:**
- "Acknowledged, will respond by [date]"
- "Delegating to [person], CC'ing you"
- "This doesn't require my input"
- "Let's schedule a call instead"
- "Unsubscribe" decision criteria

**6. The initial purge:**
- Step-by-step plan to go from [CURRENT COUNT] to zero
- What to archive vs. what needs action
- Time estimate for the purge

**7. Weekly maintenance routine:**
- 15-minute Friday cleanup checklist
```

### How to Use
Start with the purge. Then commit to the batching schedule for 2 weeks. Email is a tool, not a job.

---

## Prompt 7: Problem Solving Framework

### Prompt

```
Help me solve this problem systematically.

Problem: [DESCRIBE THE PROBLEM IN DETAIL]
Impact: [WHAT HAPPENS IF THIS ISN'T SOLVED]
Attempted solutions: [WHAT YOU'VE ALREADY TRIED]
Constraints: [CONSTRAINTS — time, budget, resources, politics]
Success looks like: [DESIRED OUTCOME]

Analyze using multiple frameworks:

**1. First Principles Thinking:**
- What are the fundamental truths here?
- What assumptions am I making?
- If I started from scratch, what would I do?

**2. Root Cause Analysis (5 Whys):**
- Why does this problem exist?
- Why? (go 5 levels deep)
- What's the actual root cause?

**3. Constraint Analysis:**
- Which constraint, if removed, would solve the problem?
- Can any constraints be relaxed?
- Are any constraints self-imposed?

**4. Inversion:**
- Instead of solving the problem, how would I make it WORSE?
- What are the opposites of those actions?

**5. Analogies:**
- Who has solved a similar problem in a different domain?
- What can I learn from their approach?

**6. Solution brainstorm (10 ideas):**
- 5 conventional solutions
- 3 creative solutions
- 2 "crazy" solutions (might work)

**7. Recommendation:**
- Best solution to try first
- Implementation plan (3-5 steps)
- How to test if it's working
- Fallback plan if it doesn't work

Force me to think differently. Don't accept my framing at face value.
```

### How to Use
Use this for any problem you've been stuck on for more than a day. The 5 Whys alone usually reveals the real issue.

---

## Prompt 8: Daily Journaling & Reflection

### Prompt

```
Create a structured daily journaling template I can use every morning and evening.

My context:
- My goals: [TOP 3 CURRENT GOALS]
- My role: [YOUR ROLE]
- What I struggle with: [COMMON CHALLENGES]
- Journaling time available: [MINUTES PER SESSION]
- Focus area: [PRODUCTIVITY / MINDSET / CREATIVITY / WELLNESS]

**Morning journal (5-10 minutes):**

1. **Gratitude (3 things):**
"I'm grateful for ___"

2. **Intention:**
"The ONE thing that would make today great is ___"

3. **Focus:**
"My top 3 priorities today are:"
- [ ] 1. ___
- [ ] 2. ___
- [ ] 3. ___

4. **Obstacle anticipation:**
"The most likely obstacle today is ___, and I'll handle it by ___"

5. **Affirmation:**
"I am ___" (present tense, positive)

**Evening journal (5-10 minutes):**

1. **Wins (3 things):**
"Today I accomplished ___"

2. **Learning:**
"The most important thing I learned today is ___"

3. **Improvement:**
"Tomorrow I'll do ___ differently because ___"

4. **Energy audit:**
"What energized me: ___"
"What drained me: ___"

5. **Score (1-10):**
"Today was a ___/10 because ___"

**Weekly review (15 minutes, Sunday):**
- Wins of the week (5+)
- What didn't get done and why
- Top priority for next week
- One relationship to invest in
- One thing to eliminate or delegate
```

### How to Use
Start with just the morning journal. Add the evening journal after 1 week. Consistency matters more than completeness.

---

## Prompt 9: Meeting-to-Action Converter

### Prompt

```
Convert these meeting notes into clear action items and summaries.

Meeting notes (paste raw notes):
"""
[PASTE YOUR MESSY MEETING NOTES, RECORDING TRANSCRIPT, OR BULLET POINTS]
"""

Meeting context:
- Meeting type: [STANDUP / STRATEGY / CLIENT / REVIEW]
- Attendees: [LIST OF PEOPLE]
- My role: [MY ROLE IN THE MEETING]

Convert into:

**1. Meeting summary (3-5 bullet points):**
- Key decisions made
- Important updates shared
- Issues raised

**2. Action items table:**
| # | Action | Owner | Deadline | Priority | Status |
|---|--------|-------|----------|----------|--------|
| 1 | | | | | Not started |

**3. Decisions log:**
- What was decided
- Key reasoning
- Who approved

**4. Open questions:**
- Unresolved items
- Who needs to answer
- By when

**5. Follow-up email:**
- Professional email to all attendees
- Summarizes meeting
- Lists action items with owners
- Notes next meeting date

**6. My personal to-dos:**
- What I specifically need to do
- Prioritized by deadline
- Estimated time for each

Extract EVERY commitment and action item — nothing should fall through the cracks.
```

### How to Use
Run this immediately after every meeting while notes are fresh. Send the follow-up email within 2 hours.

---

## Prompt 10: Data Analysis & Interpretation

### Prompt

```
Help me analyze this data and extract actionable insights.

Data:
"""
[PASTE YOUR DATA — spreadsheet values, survey results, analytics numbers, financial data, etc.]
"""

Context:
- What this data represents: [DESCRIBE]
- Time period: [TIMEFRAME]
- Key question I'm trying to answer: [QUESTION]
- Decisions this will inform: [WHAT YOU'LL DO WITH THE INSIGHTS]

Analyze:

**1. Summary statistics:**
- Key numbers at a glance
- Trends (up, down, flat)
- Outliers or anomalies

**2. Pattern analysis:**
- What patterns or trends are visible?
- Any seasonal or cyclical patterns?
- Correlations between variables

**3. Comparison:**
- How does this compare to industry benchmarks?
- How does this compare to previous periods?
- What's performing above/below expectations?

**4. Root causes:**
- What's driving the trends?
- What changed that might explain shifts?
- What external factors might be at play?

**5. Actionable insights (top 5):**
For each insight:
- The insight
- Supporting data point
- Recommended action
- Expected impact if action is taken
- Urgency: Act now / Plan for / Monitor

**6. Visualization suggestions:**
- What charts/graphs would best show this data
- What to put on each axis
- Key callouts to highlight

Present findings as if briefing an executive — clear, concise, actionable.
```

### How to Use
Don't just collect data — act on it. Every data review should produce at least one change in behavior or strategy.

---

## Prompt 11: Goal Breakdown & Tracking

### Prompt

```
Help me break down a big goal into actionable daily tasks.

My goal: [STATE YOUR GOAL — be specific and measurable]
Deadline: [TIMEFRAME]
Current status: [WHERE I AM NOW]
Resources available: [TIME, MONEY, TEAM, TOOLS]
Biggest obstacle: [WHAT'S IN THE WAY]

Break down into:

**1. Milestone map:**
- Final goal → Work backwards
- Monthly milestones
- Weekly targets
- Daily actions

**2. Lead indicators:**
- Activities I can control that drive the outcome
- Daily minimums for each (the "non-negotiables")
- How to track them (simple system)

**3. Lag indicators:**
- Outcome metrics to measure weekly
- Benchmarks that show I'm on track
- Warning signs I'm falling behind

**4. Weekly scorecard:**
| Metric | Target | Actual | On Track? |
|--------|--------|--------|-----------|
| [Metric 1] | | | |

**5. Accountability system:**
- When to review progress
- Who to report to (accountability partner)
- Consequences for missing targets
- Rewards for hitting milestones

**6. Contingency plan:**
- If I'm 2 weeks behind, I'll ___
- If [obstacle] happens, I'll ___
- Minimum viable version of this goal

The key question: "What must I do TODAY to make progress toward this goal?"
```

### How to Use
Print the daily actions and check them off. Review the scorecard every Sunday. Adjust the plan, never the goal.

---

## Pro Tips: Productivity

1. **Deep work blocks** — Protect 2-3 hours daily for focused work. No notifications.
2. **The 2-minute rule** — If it takes less than 2 minutes, do it now
3. **Eat the frog** — Do the hardest thing first when your energy is highest
4. **Energy management > Time management** — Track when you're sharp and when you're drained
5. **Say no by default** — Every yes to something is a no to something else
6. **Weekly reviews are non-negotiable** — 30 minutes on Sunday prevents a chaotic Monday
7. **Done is better than perfect** — Ship it, then iterate
