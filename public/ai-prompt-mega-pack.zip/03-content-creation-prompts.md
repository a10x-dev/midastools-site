# Midas Tools — AI Prompt Mega Pack
# 03: Content Creation Prompts

Create more content in less time. These prompts help you write blog posts, scripts, newsletters, and more — all optimized for engagement and SEO.

---

## Variables Reference

```
[TOPIC] — The subject of your content
[TARGET AUDIENCE] — Who you're creating for
[YOUR NICHE] — Your area of expertise
[KEYWORD] — Primary SEO keyword to target
[PLATFORM] — Where this content will be published
[WORD COUNT] — Desired length
[TONE] — conversational, professional, witty, academic, etc.
[YOUR BRAND] — Your business or personal brand
[SOURCE CONTENT] — Original content to repurpose
```

---

## Prompt 1: Blog Post (SEO-Optimized)

### Prompt

```
Write a comprehensive, SEO-optimized blog post about [TOPIC].

Details:
- Primary keyword: [KEYWORD]
- Secondary keywords: [LIST 3-5 RELATED KEYWORDS]
- Target audience: [TARGET AUDIENCE]
- Word count: [WORD COUNT] words
- Tone: [TONE]

Structure:
1. **Title** — Include [KEYWORD], under 60 characters, create curiosity
2. **Meta description** — 150-160 characters, include keyword, compelling
3. **Introduction** (100-150 words) — Hook with a stat, question, or bold claim. State what they'll learn.
4. **H2 sections** (3-5) — Each covering a subtopic, with [KEYWORD] variations in headings
5. **H3 subsections** — Break down complex sections
6. **Conclusion** — Summarize key points, include CTA
7. **FAQ section** — 3-5 questions with concise answers (targets featured snippets)

SEO requirements:
- Use [KEYWORD] in first 100 words
- Include keyword in at least 2 H2 headings
- Use semantic variations throughout
- Include internal link suggestions (where to link to other pages)
- Suggest 1-2 external authority links
- Write alt-text for any suggested images
- Keep paragraphs under 3 sentences
- Include at least one numbered list and one bullet list
```

### How to Use
Publish on your blog, then repurpose into social media posts, newsletter content, and video scripts.

---

## Prompt 2: YouTube Video Script

### Prompt

```
Write a YouTube video script about [TOPIC].

Details:
- Target audience: [TARGET AUDIENCE]
- Video length: [5/10/15/20 MINUTES]
- Style: [EDUCATIONAL / TUTORIAL / LISTICLE / STORY]
- Tone: [TONE]

Script format:

**HOOK (0:00-0:30)**
- Open with a bold statement, shocking stat, or preview of the result
- Tell them exactly what they'll learn and why it matters
- Pattern interrupt — something unexpected in the first 5 seconds

**INTRO (0:30-1:30)**
- Brief context — why this topic matters NOW
- Establish credibility (your experience)
- Roadmap: "We'll cover [X], [Y], and [Z]"

**MAIN CONTENT (1:30-[LENGTH-2:00])**
- Break into clear sections with transitions
- Each section: Point → Example → Application
- Include "But here's the thing..." moments (retention hooks)
- Add B-roll/visual suggestions in [brackets]
- Include 2-3 "engagement triggers" ("Comment below if you've experienced this")

**CLIMAX ([LENGTH-2:00]-[LENGTH-1:00])**
- The big reveal, ultimate tip, or most valuable insight
- Save something special for viewers who watch to the end

**OUTRO (last 60 seconds)**
- Summarize the top 3 takeaways
- CTA: Subscribe + one specific next step
- Tease next video topic

Also provide:
- 5 title options (optimize for click-through rate)
- Description (500 words, include keywords and timestamps)
- 10 tag suggestions
- Thumbnail concept (text + visual description)
```

### How to Use
Read the script aloud to check pacing. A good 10-minute script is ~1,500 words. Film the hook 3 different ways and use the best.

---

## Prompt 3: Newsletter Writer

### Prompt

```
Write a newsletter edition about [TOPIC] for my [TARGET AUDIENCE] audience.

Newsletter details:
- Name: [NEWSLETTER NAME]
- Niche: [YOUR NICHE]
- Tone: [TONE]
- Frequency: [WEEKLY / BIWEEKLY / MONTHLY]

Structure:

**Subject line** — 5 options (optimize for open rate, under 50 chars)
**Preview text** — Complements subject line, 40-90 chars

**Opening (2-3 sentences)**
- Personal, conversational opener
- Connect to something timely or relatable

**Main content (400-600 words)**
- One key insight or lesson about [TOPIC]
- Include a personal story or example
- Actionable takeaway they can use today
- Use subheadings to break up text

**Quick hits (3-5 bullet points)**
- Links, tools, or tips related to [YOUR NICHE]
- Each: one-line description + link placeholder

**CTA**
- One clear action: reply, click, try something
- Make it feel personal, not transactional

**Sign-off**
- Warm, personal close
- PS line with a teaser for next issue

Total length: 500-800 words (respect inbox time)
```

### How to Use
Batch-write 4 newsletters at once. Schedule them weekly. Consistency matters more than perfection.

---

## Prompt 4: Podcast Show Notes & Script

### Prompt

```
Create a podcast episode outline and show notes for an episode about [TOPIC].

Podcast details:
- Show name: [PODCAST NAME]
- Host: [YOUR NAME]
- Episode type: [SOLO / INTERVIEW / CO-HOST]
- Duration: [LENGTH] minutes
- Audience: [TARGET AUDIENCE]

**Episode outline:**

1. **Cold open (30 seconds)** — Teaser of the best moment
2. **Intro (1-2 min)** — Welcome, what's covered, why it matters
3. **Segment 1 (X min)** — [SUBTOPIC 1] with talking points
4. **Segment 2 (X min)** — [SUBTOPIC 2] with talking points
5. **Segment 3 (X min)** — [SUBTOPIC 3] with talking points
6. **Rapid fire / Q&A (3-5 min)** — Quick hits related to [TOPIC]
7. **Outro (1-2 min)** — Summary, CTA, next episode tease

For each segment, provide:
- 3-5 talking points (not a script — keep it natural)
- One story or example to share
- Transition sentence to next segment

**Show notes (for podcast page/app):**
- Episode title (5 options)
- Description (200 words, SEO-optimized)
- Timestamps for each segment
- Links/resources mentioned
- Guest bio (if interview)
- CTA: subscribe, review, share

**Social promotion:**
- 3 audiogram quotes (15-30 seconds, highest-value moments)
- Tweet promoting the episode
- LinkedIn post promoting the episode
```

### How to Use
Use the outline as a guide, not a script. Podcast listeners prefer natural conversation. Record in one take, edit minimally.

---

## Prompt 5: Content Repurposing Engine

### Prompt

```
Take the following source content and repurpose it into 8 different formats.

Source content:
"""
[PASTE YOUR SOURCE CONTENT — blog post, video transcript, podcast notes, etc.]
"""

Repurpose into:

1. **Twitter/X thread (10 tweets)** — Key insights as a thread
2. **LinkedIn post** — Professional angle, personal story format
3. **Instagram carousel (8-10 slides)** — Visual-friendly, one point per slide
4. **TikTok/Reels script (60 sec)** — Hook + value + CTA
5. **Newsletter snippet (200 words)** — One key takeaway, expanded
6. **Email teaser** — Subject line + 100-word teaser linking to full content
7. **Quote graphics (5)** — Pull the most quotable sentences for image posts
8. **YouTube Shorts script (60 sec)** — Different angle than TikTok version

For each format:
- Adapt the message for that platform's culture
- Adjust length and tone appropriately
- Include platform-specific formatting (hashtags, line breaks, etc.)
- Ready to copy-paste and publish

Note: Don't just copy-paste — transform the core message for each platform.
```

### How to Use
Create your "pillar" content first (blog post, video, or podcast), then run it through this prompt. One piece of content → 8 posts in 15 minutes.

---

## Prompt 6: Blog Post Title A/B Tester

### Prompt

```
I'm writing a blog post about [TOPIC] targeting [TARGET AUDIENCE].

Primary keyword: [KEYWORD]

Generate 20 title options using these proven formulas:

**How-to (5 titles):**
- "How to [Achieve Result] in [Timeframe]"
- "How to [Do Thing] Without [Common Obstacle]"

**List/Number (5 titles):**
- "[Number] [Things] That [Promise]"
- "[Number] [Adjective] Ways to [Achieve Goal]"

**Question (3 titles):**
- "Why [Surprising Fact]?"
- "What Happens When [Scenario]?"

**Guide/Resource (3 titles):**
- "The Complete Guide to [Topic] in [Year]"
- "The [Audience]'s Guide to [Topic]"

**Curiosity/Controversial (4 titles):**
- "Why [Common Practice] Is [Negative Outcome]"
- "[Thing] Is Dead. Here's What's Next."

For each title:
- Include [KEYWORD] naturally
- Rate click-through potential 1-10
- Note: which audience segment it appeals to most
- Keep under 60 characters for SEO

Recommend the top 5 for A/B testing.
```

### How to Use
Test your top 2 titles as social media posts. The one that gets more engagement becomes your blog post title.

---

## Prompt 7: Content Brief (for Writers/VAs)

### Prompt

```
Create a detailed content brief for a blog post about [TOPIC].

This brief will be given to a writer or VA to produce the content.

**Content Brief:**

**Title:** [Suggested title]
**Target keyword:** [KEYWORD]
**Secondary keywords:** [LIST]
**Word count:** [WORD COUNT]
**Target audience:** [TARGET AUDIENCE]
**Search intent:** [Informational / Commercial / Transactional]
**Competitors to outperform:** [LIST 2-3 COMPETING URLS]

**Outline:**
- H1: [Title]
- H2: [Section 1]
  - H3: [Subsection]
  - H3: [Subsection]
- H2: [Section 2]
  - H3: [Subsection]
- [Continue...]
- H2: FAQ

**Key points to cover:**
- [Must-include point 1]
- [Must-include point 2]
- [Must-include point 3]

**Tone & style:**
- [Tone description]
- [Example sentence in the desired voice]
- [Things to avoid]

**Internal links to include:**
- [Page URL] — anchor text suggestion

**Visual suggestions:**
- [Where to add images/diagrams]
- [Alt text suggestions]

**SEO checklist:**
- [ ] Keyword in title
- [ ] Keyword in first 100 words
- [ ] Keyword in at least 1 H2
- [ ] Meta description written
- [ ] At least 2 internal links
- [ ] 1 external authority link

**Examples of good posts on this topic:**
- [URL 1 — what they did well]
- [URL 2 — what they missed that we should cover]
```

### How to Use
Use this when delegating content creation. A good brief takes 15 minutes and saves hours of revision.

---

## Prompt 8: Email Newsletter Subject Lines

### Prompt

```
Generate 30 email subject lines for my [YOUR NICHE] newsletter.

Audience: [TARGET AUDIENCE]
Newsletter topic this week: [TOPIC]
Tone: [TONE]

Create 5 subject lines for each category:

**1. Curiosity gap:**
"The [thing] nobody talks about in [niche]"

**2. Number/List:**
"[Number] [things] I [did] this week"

**3. Personal/Story:**
"I almost [negative thing]... then [positive thing]"

**4. Direct benefit:**
"How to [achieve specific result] by [timeframe]"

**5. Question:**
"Are you still [doing thing the wrong way]?"

**6. Urgent/Timely:**
"[Topic] is changing in [year]. Here's what to do."

For each:
- Under 50 characters (mobile-friendly)
- No ALL CAPS or excessive punctuation
- Rate expected open rate: Low / Medium / High
- Suggest matching preview text (40-90 chars)

Top 5 recommendation with reasoning.
```

### How to Use
A/B test your top 2 subject lines with a 10% sample of your list. Send the winner to the remaining 90%.

---

## Prompt 9: Pillar Content Strategy

### Prompt

```
Design a pillar content strategy for [YOUR BRAND] targeting [TARGET AUDIENCE].

My niche: [YOUR NICHE]
My products: [LIST PRODUCTS/SERVICES]
Top 5 keywords I want to rank for: [LIST KEYWORDS]

Create:

**3 Pillar pages** (comprehensive, 3,000+ word guides):
For each pillar:
- Title
- Target keyword
- Outline (H2 and H3 headings)
- Word count recommendation
- Internal linking structure

**15 Cluster posts** (5 per pillar, 1,000-1,500 words each):
For each cluster:
- Title
- Target keyword (long-tail)
- How it links back to the pillar
- Brief outline
- Estimated traffic potential: Low / Medium / High

**Content map** showing how everything connects:
- Pillar → Cluster linking diagram
- Publishing schedule (which to publish first for maximum SEO impact)
- Quick wins vs. long-term plays

**Expected outcomes:**
- Month 1-3: What to expect
- Month 3-6: Growth trajectory
- Month 6-12: Compounding effects
```

### How to Use
Publish pillar pages first, then cluster posts over the following weeks. Each cluster post should link back to its pillar page. This is the #1 SEO strategy for 2026.

---

## Prompt 10: Content Audit

### Prompt

```
Help me audit my existing content strategy.

My content inventory:
[LIST YOUR EXISTING CONTENT — blog posts, videos, social media profiles, etc.]

My goals:
- Primary: [GOAL — traffic, leads, sales, authority]
- Audience: [TARGET AUDIENCE]
- Key product to promote: [PRODUCT/SERVICE]

Analyze and provide:

**1. Content gaps:**
- What topics is my audience searching for that I haven't covered?
- What content types am I missing? (video, podcast, newsletter, etc.)
- What stages of the buyer journey are underserved?

**2. Optimization opportunities:**
- Which existing content could be updated for more traffic?
- Which posts could be combined into a comprehensive guide?
- Where should I add CTAs or internal links?

**3. Repurposing opportunities:**
- Which content can be turned into other formats?
- What's my best-performing content that deserves more distribution?

**4. Content calendar (next 30 days):**
- What to create first based on impact vs. effort
- Mix of content types and topics
- Publication schedule

**5. KPIs to track:**
- Which metrics matter for my goals
- Benchmarks to aim for
- Tools to use for tracking
```

### How to Use
Run this audit quarterly. The best content strategy is built on data, not guesses.

---

## Pro Tips: Content Creation

1. **The 1-hour content system** — 20 min writing, 20 min editing, 20 min distribution
2. **Batch create** — Write 4 posts at once, not 1 per day
3. **Headline first** — Write 10 headlines, pick the best, THEN write the post
4. **The 80/20 of SEO** — Keyword in title, first paragraph, one H2, and meta description covers 80% of on-page SEO
5. **Evergreen > Trending** — Create content that's still valuable in 12 months
6. **Steal like an artist** — Study what performs in your niche, then make it better and put your spin on it
7. **Distribution > Creation** — Spend as much time promoting as you do creating
