# Midas Tools — AI Prompt Mega Pack
# 04: Business Operations Prompts

Run your business smarter with AI. From emails to SOPs, meeting notes to hiring — these prompts handle the operational work that eats your time.

---

## Variables Reference

```
[YOUR BUSINESS] — Your company name
[YOUR INDUSTRY] — Your market/niche
[YOUR ROLE] — Your title or position
[TEAM SIZE] — Number of people
[TASK] — The specific task or process
[DEPARTMENT] — Team or department
[DEADLINE] — Due date
[BUDGET] — Available budget
[STAKEHOLDER] — Person or group involved
```

---

## Prompt 1: Professional Email Writer

### Prompt

```
Write a professional email for the following situation:

Context:
- From: [YOUR NAME], [YOUR ROLE] at [YOUR BUSINESS]
- To: [RECIPIENT NAME], [THEIR ROLE]
- Relationship: [NEW CONTACT / EXISTING CLIENT / VENDOR / TEAM MEMBER / EXECUTIVE]
- Purpose: [WHAT YOU NEED — request, update, follow-up, complaint, negotiation]
- Key details: [SPECIFIC INFORMATION TO INCLUDE]
- Tone: [FORMAL / PROFESSIONAL-FRIENDLY / CASUAL / URGENT]
- Desired outcome: [WHAT YOU WANT THEM TO DO]

Write 3 versions:
1. **Concise** (under 100 words) — for busy recipients
2. **Standard** (150-200 words) — for most situations
3. **Detailed** (250-350 words) — when context matters

Each version must:
- Have a clear subject line
- Open with purpose (no "I hope this email finds you well")
- Include specific ask with deadline
- Close with clear next step
- Be scannable (short paragraphs, bold key info)

Also write a follow-up email to send if no response in 3 days.
```

### How to Use
Pick the version that matches the recipient's communication style. Senior executives prefer concise. New contacts need more context.

---

## Prompt 2: SOP (Standard Operating Procedure) Creator

### Prompt

```
Create a detailed Standard Operating Procedure (SOP) for [TASK].

Context:
- Business: [YOUR BUSINESS]
- Department: [DEPARTMENT]
- Who performs this: [ROLE/TITLE]
- Frequency: [DAILY / WEEKLY / AS NEEDED]
- Current process: [BRIEF DESCRIPTION OF HOW IT'S DONE NOW]
- Pain points: [WHAT GOES WRONG OR TAKES TOO LONG]

SOP format:

**Document header:**
- SOP Title
- Version number
- Last updated
- Owner
- Approved by

**Purpose:** Why this process exists (1-2 sentences)

**Scope:** What this SOP covers and doesn't cover

**Prerequisites:** What's needed before starting (tools, access, info)

**Step-by-step procedure:**
- Numbered steps with clear actions (start each with a verb)
- Decision points: "If [X], go to step [Y]"
- Screenshots/visual placeholders where helpful
- Expected time for each step
- Quality checkpoints

**Troubleshooting:** Common issues and fixes (5 scenarios)

**Metrics:** How to measure if the process is working

**Revision history:** Template for tracking changes

Make it so clear that someone with NO prior knowledge could follow it perfectly.
```

### How to Use
Document your top 10 recurring processes. SOPs are what let you delegate, hire, and scale.

---

## Prompt 3: Meeting Agenda & Notes

### Prompt

```
Create a meeting agenda and post-meeting summary template.

Meeting details:
- Purpose: [MEETING PURPOSE]
- Attendees: [LIST OF PEOPLE AND ROLES]
- Duration: [LENGTH]
- Type: [STANDUP / STRATEGY / CLIENT / REVIEW / BRAINSTORM / 1-ON-1]

**Pre-meeting agenda:**

1. **Meeting title and objective** (one sentence)
2. **Pre-reads** — What attendees should review beforehand
3. **Agenda items** with time allocations:
   - Item 1: [TOPIC] — [X] min — [DISCUSSION / DECISION / UPDATE]
   - Item 2: [TOPIC] — [X] min — [DISCUSSION / DECISION / UPDATE]
   - Item 3: [TOPIC] — [X] min — [DISCUSSION / DECISION / UPDATE]
4. **Parking lot** — Items to address later
5. **Next steps preview**

**Post-meeting notes template:**

1. **Date/Time/Attendees**
2. **Key decisions made** (bullet points)
3. **Action items** — Who / What / By When
4. **Open questions** — Unresolved items
5. **Next meeting** — Date and pre-work

Also provide:
- 3 ground rules for productive meetings
- A "meeting necessity test" (should this meeting even happen?)
- Email template to send agenda beforehand
- Email template to send notes afterward
```

### How to Use
Send the agenda 24 hours before. Send notes within 2 hours after. If a meeting has no agenda, it shouldn't happen.

---

## Prompt 4: Hiring & Job Post Writer

### Prompt

```
Write a compelling job post for a [JOB TITLE] position at [YOUR BUSINESS].

Details:
- Role: [JOB TITLE]
- Type: [FULL-TIME / PART-TIME / CONTRACT / FREELANCE]
- Location: [REMOTE / HYBRID / ON-SITE — CITY]
- Salary range: [RANGE OR "COMPETITIVE"]
- Department: [TEAM]
- Reports to: [MANAGER TITLE]
- Start date: [WHEN]

Context:
- Company size: [TEAM SIZE]
- Industry: [YOUR INDUSTRY]
- Company culture: [DESCRIBE IN 2-3 ADJECTIVES]
- Biggest challenge this role solves: [PROBLEM]

Write:

**Job post (for LinkedIn/Indeed):**
- Attention-grabbing opening (NOT "We're looking for...")
- About the role — what they'll actually DO (not just responsibilities)
- About you — qualities that matter more than credentials
- What we offer — beyond salary (growth, culture, flexibility)
- How to apply — clear instructions with timeline

**Job post (for niche communities/Twitter):**
- Casual, personality-driven version (300 words max)
- Shows culture, not just requirements

**Screening questions:**
- 5 questions to filter applicants quickly
- Mix of experience, problem-solving, and culture fit
- Include one "wildcard" question that reveals character

**Interview scorecard:**
- 5 evaluation criteria with 1-5 rating scale
- What "5" looks like for each criterion
- Red flags to watch for
```

### How to Use
Post the formal version on job boards, the casual version on social media and communities. Use the scorecard for consistent evaluation.

---

## Prompt 5: Financial Analysis / Business Metrics

### Prompt

```
Help me analyze my business metrics and create an action plan.

Current metrics:
- Monthly revenue: [AMOUNT]
- Monthly expenses: [AMOUNT]
- Revenue sources: [BREAK DOWN BY PRODUCT/SERVICE]
- Customer count: [NUMBER]
- Average order value: [AMOUNT]
- Customer acquisition cost: [AMOUNT OR "UNKNOWN"]
- Churn rate: [PERCENTAGE OR "UNKNOWN"]
- Website traffic: [MONTHLY VISITORS]
- Conversion rate: [PERCENTAGE]
- Growth rate (MoM): [PERCENTAGE]

Analyze:

**1. Financial health check:**
- Profit margin and sustainability assessment
- Revenue concentration risk
- Burn rate (if applicable)

**2. Key ratios:**
- LTV:CAC ratio (or how to calculate it)
- Revenue per customer
- Operating efficiency

**3. Growth levers:**
- Which metric, if improved by 10%, would have the biggest impact?
- Low-hanging fruit optimizations
- Revenue diversification opportunities

**4. Monthly dashboard:**
- Which 5 metrics should I track weekly?
- What are healthy benchmarks for my stage?
- Alert thresholds (when to worry)

**5. 90-day action plan:**
- Top 3 priorities for growth
- Specific, measurable goals
- Resources needed

Present with tables and clear numbers where possible.
```

### How to Use
Run this analysis monthly. Track the 5 key metrics weekly. Review with your co-founder or advisor quarterly.

---

## Prompt 6: Customer Service Response Templates

### Prompt

```
Create customer service response templates for [YOUR BUSINESS].

Business: [YOUR BUSINESS]
Product/Service: [PRODUCT/SERVICE]
Support channel: [EMAIL / CHAT / SOCIAL MEDIA]
Brand voice: [TONE]

Write templates for these scenarios:

**Positive interactions:**
1. Thank you for purchase / welcome email
2. Positive review response
3. Referral thank you
4. Milestone celebration (1-year customer, etc.)

**Problem resolution:**
5. Product issue / bug report acknowledgment
6. Refund request (approved)
7. Refund request (denied — with alternative)
8. Delayed delivery / service
9. Billing error correction

**Difficult situations:**
10. Angry customer (de-escalation)
11. Unreasonable request (boundary setting)
12. Feature request (not planned)
13. Service outage / downtime notification

**Proactive outreach:**
14. Check-in after purchase (7 days)
15. Re-engagement (inactive 30 days)
16. Feedback request
17. Upgrade/upsell opportunity

For each template:
- Write the complete response (ready to send)
- Include [BRACKETS] for personalization
- Note the emotional goal (reassure, excite, resolve, etc.)
- Keep under 150 words
- Suggest follow-up timing
```

### How to Use
Load these into your support tool as canned responses. Personalize the brackets for each customer. Speed + personalization = great support.

---

## Prompt 7: Project Planning & Scope

### Prompt

```
Create a project plan for [PROJECT NAME].

Project details:
- Objective: [WHAT YOU'RE BUILDING/DOING]
- Deadline: [DEADLINE]
- Budget: [BUDGET]
- Team: [WHO'S INVOLVED AND THEIR ROLES]
- Stakeholders: [WHO NEEDS TO APPROVE/REVIEW]

Deliverables:

**1. Project scope document:**
- Objective (1 sentence)
- Success criteria (3-5 measurable outcomes)
- In scope / Out of scope
- Assumptions
- Risks and mitigation

**2. Work breakdown:**
- Phases with milestones
- Tasks within each phase
- Estimated hours per task
- Dependencies (what must happen before what)
- Assignee for each task

**3. Timeline (Gantt-style):**
- Weekly view from start to deadline
- Key milestones marked
- Buffer time built in (20% of total)

**4. Risk register:**
- Top 5 risks
- Probability (Low/Medium/High)
- Impact (Low/Medium/High)
- Mitigation plan for each

**5. Communication plan:**
- Status update frequency
- Stakeholder update template
- Escalation path

Present the work breakdown as a table. Include total estimated hours and compare to deadline feasibility.
```

### How to Use
Share this plan before starting work. Review progress against milestones weekly. Adjust scope early if you're falling behind.

---

## Prompt 8: Vendor/Partner Negotiation

### Prompt

```
Help me prepare for a negotiation with [VENDOR/PARTNER NAME].

Context:
- What we're negotiating: [CONTRACT / PRICE / TERMS / PARTNERSHIP]
- Current deal: [CURRENT TERMS]
- What we want: [DESIRED OUTCOME]
- Our leverage: [WHAT GIVES US BARGAINING POWER]
- Their likely position: [WHAT THEY PROBABLY WANT]
- Relationship importance: [ONE-TIME / ONGOING / STRATEGIC]
- Our BATNA (best alternative): [WHAT WE'LL DO IF THIS FALLS THROUGH]

Provide:

**1. Preparation checklist:**
- Research to do before the meeting
- Key data points to have ready
- Questions to ask them

**2. Negotiation strategy:**
- Opening position
- Target outcome
- Walk-away point
- Concessions we can make (low cost to us, high value to them)
- Concessions to ask for (high value to us)

**3. Talking points:**
- Opening statement
- Value proposition (why they should agree)
- Objection responses (top 5 things they might push back on)

**4. Email templates:**
- Pre-meeting: Setting the agenda
- Post-meeting: Confirming agreed terms
- Follow-up: If they stall or counter-offer

**5. Red flags to watch for:**
- Signs they're not negotiating in good faith
- Hidden costs or terms to look for
```

### How to Use
Never negotiate without preparation. The side that prepares more usually wins. Practice your talking points out loud before the meeting.

---

## Prompt 9: Business Strategy Canvas

### Prompt

```
Help me think through my business strategy using a structured framework.

Business: [YOUR BUSINESS]
Stage: [IDEA / EARLY / GROWING / SCALING]
Industry: [YOUR INDUSTRY]
Revenue: [CURRENT OR TARGET]
Team: [TEAM SIZE]

Fill out these strategic frameworks:

**1. Business Model Canvas:**
- Customer Segments
- Value Propositions
- Channels
- Customer Relationships
- Revenue Streams
- Key Resources
- Key Activities
- Key Partnerships
- Cost Structure

**2. SWOT Analysis:**
- Strengths (internal)
- Weaknesses (internal)
- Opportunities (external)
- Threats (external)
- For each item: one action to take

**3. Competitive Positioning:**
- Top 3 competitors
- Where we win
- Where we lose
- Our unique angle

**4. Growth Strategy (next 12 months):**
- Primary growth lever
- Secondary growth lever
- Key milestones (quarterly)
- Resource requirements

**5. Decision Framework:**
- What should we say YES to?
- What should we say NO to?
- One thing to stop doing
- One thing to start doing
- One thing to do more of

Be direct. Challenge my assumptions. Tell me what I might be missing.
```

### How to Use
Review this quarterly. Share with advisors, co-founders, or mentors for feedback. Update as your understanding of the market evolves.

---

## Prompt 10: Crisis Communication

### Prompt

```
Help me draft crisis communication for [YOUR BUSINESS].

Situation: [DESCRIBE THE CRISIS — data breach, service outage, PR issue, product recall, etc.]
Severity: [LOW / MEDIUM / HIGH / CRITICAL]
Who's affected: [CUSTOMERS / PARTNERS / EMPLOYEES / PUBLIC]
Current status: [WHAT'S HAPPENING RIGHT NOW]
What we know: [CONFIRMED FACTS]
What we don't know: [UNKNOWNS]
Timeline: [WHEN DID IT START, WHEN WILL IT BE RESOLVED]

Write:

**1. Internal notification (for team):**
- What happened
- What we're doing
- What each person should do
- What NOT to say publicly

**2. Customer notification (email):**
- Honest, clear explanation
- What we're doing to fix it
- What they need to do (if anything)
- Timeline for resolution
- Apology without over-apologizing

**3. Public statement (for website/social):**
- Brief, factual, transparent
- Shows we're taking it seriously
- No corporate jargon

**4. FAQ for support team:**
- Top 10 questions customers will ask
- Approved answers for each

**5. Follow-up communication (after resolution):**
- What happened (full transparency)
- What we did to fix it
- What we're doing to prevent it
- Any compensation or goodwill gesture

Tone: Honest, calm, accountable. Never defensive or dismissive.
```

### How to Use
Have crisis templates BEFORE you need them. The first 4 hours of a crisis determine public perception.

---

## Pro Tips: Business Operations

1. **Document everything** — If only one person knows how to do it, it's a liability
2. **Automate the boring stuff** — Every recurring task should be automated or templated
3. **The 2-minute rule** — If it takes less than 2 minutes, do it now
4. **One meeting, one decision** — Every meeting should produce a decision or action item
5. **Templates save thousands of hours** — Write it once, use it forever
6. **Regular reviews** — Monthly financial review, quarterly strategy review, weekly team check-in
7. **Your inbox is not your to-do list** — Process email in batches, not continuously
